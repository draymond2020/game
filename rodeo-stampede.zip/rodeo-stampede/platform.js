const _0x4500 = [
    'error',
    'getInstance',
    'inline',
    'navigate',
    'LocalStorage',
    'floor',
    'none',
    'onSoundStatechange',
    'WebAudioEngine',
    'isSuspend',
    '_musicVolume',
    'visibilityState',
    'showBanner',
    'musicAudio',
    'stopAll',
    'panner',
    'Web\x20Audio\x20API\x20is\x20not\x20supported\x20in\x20this\x20browser',
    'showInterstitial',
    'https://www.bestgames.com/',
    'state',
    'playMusic',
    'parse',
    'MORE',
    'decodeAudioData',
    'has',
    'https://www.yiv.com/',
    'set',
    'onComplete',
    'musicVolume',
    'onstatechange',
    'onError',
    'create',
    'split',
    'opacity',
    'hidden',
    'SoundManager',
    'log',
    'onblur',
    'createLogo',
    'onload',
    'forgame/games.json',
    'ended',
    'bind',
    'loader',
    'focus',
    'initialized_',
    'then',
    'utm_source=',
    'isInited',
    'instance',
    'prompt',
    'LOGO',
    'document',
    'skin',
    'arraybuffer',
    'renderHandler',
    'layaCanvas',
    'Failed\x20to\x20get\x20the\x20reward,\x20please\x20watch\x20the\x20ads\x20to\x20the\x20end.',
    'application/x-www-form-urlencoded;\x20charset=UTF-8',
    'undefined',
    'forgames',
    'soundAudio',
    '?pic=',
    'gamemonetize',
    'YAD',
    'stringify',
    'adShowing',
    'YYGSDK_INITIALIZED',
    'referrer',
    'isGamedistribution',
    'Web\x20Audio\x20API',
    '_instance',
    'CARGAMES',
    'https://www.yad.com/',
    'source',
    'initData',
    'display',
    'head',
    'isMuted',
    'rolloffFactor',
    'open',
    'mousedown',
    'adsAsyncInit',
    'bePauseSound',
    'AudioContext',
    'random',
    'tryToResumeAudioContext',
    'stopMusic',
    'onfocus',
    'downloadArrayBuffer',
    'body',
    'cssText',
    'stop',
    'ontimeout',
    '_stopSound',
    'gameNameId',
    'script',
    'src',
    's\x20ease-in,\x20opacity\x20',
    'webkitTransition',
    'suspend',
    'onSuccess',
    'createGain',
    'canNavigateActive_',
    'appendChild',
    'setup',
    'playBuffer',
    'type',
    'isVisibilityMuted',
    'sdkSuccess',
    'Decode\x20error.',
    'GAME',
    'TYPE',
    'trim',
    'Image',
    'onVisibilitychange',
    'action_',
    'pauseSound',
    'removeEventListener',
    '_music',
    'send',
    'load',
    'pause',
    'currentTime',
    'getItem',
    'webkitAudioContext',
    'onprogress',
    '-webkit-transform\x20',
    'screen_',
    'resume',
    'onabort',
    'onNavigate_',
    'responseText',
    '&utm_campaign=game-',
    'addEventListener',
    'font-family:siyuan;max-width:80%;min-width:320px;padding:10px\x2010px\x2010px\x2010px;min-height:40px;color:\x20rgb(255,\x20255,\x20255);line-height:\x2020px;text-align:center;border-radius:\x204px;position:\x20fixed;top:\x2040%;left:\x2050%;transform:\x20translate(-50%,\x20-50%);z-index:\x20999999;background:\x20rgba(0,\x200,\x200,.7);font-size:\x2016px;',
    'pauseMusic',
    'length',
    'volume',
    'text',
    'prompt_',
    'SDK_OPTIONS',
    'Event',
    'setupPanning',
    'cnf.json',
    'getStorageSync',
    'buffer',
    'ChannelType',
    'gamedistributionID',
    'SDK_GAME_START',
    'https://cargames.com/',
    '__init__',
    'disconnect',
    'dataSource',
    'getContext',
    'values',
    '&utm_medium=',
    'onerror',
    'gain',
    'play',
    'getElementById',
    'appName',
    'tryToResumeIntervalId',
    'url',
    'playBuffer\x20error.\x20Exception:\x20',
    'init',
    'GET',
    'getForgames',
    'mouseup',
    'sdk',
    'playSound',
    'REWARD',
    'SDK_READY',
    'get',
    'indexOf',
    'Options',
    'GamemonetizeAdsInstance_AD_WEB',
    'context',
    'no\x20response',
    'beEnabled',
    'AD_SKIPPED',
    'style',
    'connect',
    'muted',
    'onMusicStatechange',
    'to_',
    'stopSound',
    'bePauseMusic',
    'response',
    'cargamesstartup',
    'createSoundInstance',
    'destination',
    '_audioInstances',
    'request',
    'createElement',
    'showReward',
    'zOrder',
    'isInitSDK',
    'onended',
    'stage',
    'array',
    'SDK_GAME_PAUSE',
    'suspended',
    'MOUSE_DOWN',
    'threeD',
    'touchstart',
    'status',
    'Handler'
];
(function (_0x4e8f2e, _0x4500a0) {
    const _0x152f5b = function (_0x264221) {
        while (--_0x264221) {
            _0x4e8f2e['push'](_0x4e8f2e['shift']());
        }
    };
    _0x152f5b(++_0x4500a0);
}(_0x4500, 0x78));
const _0x152f = function (_0x4e8f2e, _0x4500a0) {
    _0x4e8f2e = _0x4e8f2e - 0x0;
    let _0x152f5b = _0x4500[_0x4e8f2e];
    return _0x152f5b;
};
!function () {
    const _0x5b2ced = _0x152f('0x38');
    class _0x1c7578 {
        constructor() {
            this[_0x152f('0x88')] = ![], this[_0x152f('0x29')] = '';
        }
        [_0x152f('0xaa')](_0x1a2aaa, _0x50c621, _0xee7f89) {
            return this['route'] = [
                'https://www.yad.com/',
                _0x152f('0x71'),
                'https://www.babygames.com/',
                _0x152f('0x6a'),
                _0x152f('0x1e'),
                _0x152f('0xa1'),
                'https://www.yad.com/',
                _0x152f('0xa1')
            ][_0x50c621], this[_0x152f('0x29')] = _0x1a2aaa, this[_0x152f('0x2f')](), new Promise((_0x538bc9, _0x49b4c5) => {
                window[_0x152f('0x15')] = {
                    'gameId': _0xee7f89,
                    'onEvent': _0x47fa99 => {
                        console[_0x152f('0x7c')]('event.name\x20====', _0x47fa99);
                        switch (_0x47fa99['name']) {
                        case _0x152f('0x51'):
                            window[_0x152f('0x60')] && (window[_0x152f('0x60')][_0x152f('0x3f')] = !![]);
                            break;
                        case _0x152f('0x1d'):
                            _0x47fa99[_0x152f('0x56')] === 'success' && (this[_0x152f('0xbd')] && (this[_0x152f('0xbd')](![]), this['onSuccess'] = null), this[_0x152f('0x73')]());
                            break;
                        case _0x152f('0x34'):
                            _0x538bc9(this[_0x152f('0x88')]);
                            break;
                        default:
                            break;
                        }
                    }
                }, this[_0x152f('0x2d')]()[_0x152f('0x86')](_0x3c7747 => {
                    this['isInited'] = _0x3c7747;
                });
            });
        }
        [_0x152f('0x2d')]() {
            return new Promise((_0x4284e6, _0x50d76e) => {
                var _0x5a64d9 = this, _0x170857 = document[_0x152f('0x28')](_0x5b2ced);
                _0x170857 && !this['isInited'] && (_0x170857 = null);
                if (!_0x170857) {
                    function _0x260569() {
                        _0x4284e6(!![]);
                    }
                    function _0x1ec8ef(_0x3128da) {
                        console[_0x152f('0x7c')](_0x152f('0x76'), _0x3128da), _0x50d76e(![]);
                    }
                    const _0x144a55 = document[_0x152f('0x4a')](_0x152f('0xb8'));
                    _0x144a55[_0x152f('0x7f')] = _0x260569[_0x152f('0x82')](this), _0x144a55[_0x152f('0x25')] = _0x1ec8ef['bind'](this), _0x144a55[_0x152f('0xc3')] = 'text/javascript', _0x144a55['async'] = ![], _0x144a55[_0x152f('0xb9')] = 'https://api.gamemonetize.com/sdk.js', _0x144a55['id'] = _0x5b2ced, document[_0x152f('0xa5')][_0x152f('0xc0')](_0x144a55);
                } else
                    _0x4284e6(!![]);
            });
        }
        [_0x152f('0x73')]() {
        }
        [_0x152f('0x49')]() {
            return new Promise((_0x3efbca, _0x3f91e9) => {
                if (!this[_0x152f('0x88')]) {
                    _0x3efbca(![]);
                    return;
                }
                this[_0x152f('0xbd')] = _0x3efbca, window[_0x152f('0x31')][_0x152f('0x64')]();
            });
        }
        ['showInterstitial'](_0x3c6785) {
            this[_0x152f('0x49')]()[_0x152f('0x86')](() => {
                _0x3c6785 && _0x3c6785();
            });
        }
        [_0x152f('0x4b')](_0x4776a2, _0x1af33a) {
            this[_0x152f('0x49')]()[_0x152f('0x86')](() => {
                _0x4776a2 && _0x4776a2();
            });
        }
        [_0x152f('0x2f')]() {
            const _0x5e75d6 = new XMLHttpRequest();
            _0x5e75d6[_0x152f('0xa8')](_0x152f('0x2e'), this['route'] + _0x152f('0x80'), !![]), _0x5e75d6['setRequestHeader']('Content-Type', _0x152f('0x92')), _0x5e75d6['responseType'] = _0x152f('0x13'), _0x5e75d6[_0x152f('0x25')] = function (_0x3270db) {
            }, _0x5e75d6[_0x152f('0xa')] = function (_0x42ec63) {
            }, _0x5e75d6[_0x152f('0x6')] = function (_0x23a259) {
            }, _0x5e75d6['onload'] = _0x4d7c87 => {
                var _0x2f40eb = _0x5e75d6[_0x152f('0x56')] !== undefined ? _0x5e75d6[_0x152f('0x56')] : 0xc8;
                if (_0x2f40eb === 0xc8 || _0x2f40eb === 0xcc || _0x2f40eb === 0x0)
                    this[_0x152f('0x94')] = JSON[_0x152f('0x6d')](_0x5e75d6[_0x152f('0xc')]);
                else {
                }
            }, _0x5e75d6['send']();
        }
        [_0x152f('0x5b')](_0x41a9e3, _0x2f18e7, _0x392835) {
            if (!_0x5e947f[_0x152f('0x59')]()[_0x152f('0xc5')])
                return;
            _0x392835 = _0x392835 || '';
            let _0x54dea6 = document[_0x152f('0x9c')];
            var _0x1076b9 = this['route'];
            if (typeof _0x392835 === _0x152f('0x93') || _0x392835 == '' || _0x392835 == _0x152f('0x93')) {
            } else
                _0x1076b9 = _0x1076b9 + _0x152f('0x96') + _0x392835;
            typeof _0x54dea6 === _0x152f('0x93') || _0x54dea6 == '' || _0x54dea6 == 'undefined' ? _0x54dea6 = 'unknown' : _0x54dea6 = _0x54dea6[_0x152f('0x78')]('/')[0x2];
            _0x1076b9[_0x152f('0x36')]('?') > -0x1 ? _0x1076b9 = _0x1076b9 + '&' : _0x1076b9 = _0x1076b9 + '?';
            _0x1076b9 = _0x1076b9 + _0x152f('0x87') + _0x54dea6 + _0x152f('0x24') + _0x41a9e3 + '-' + _0x2f18e7 + _0x152f('0xd') + this[_0x152f('0x29')];
            try {
                if (window[_0x152f('0xa8')](_0x1076b9)) {
                } else {
                }
            } catch (_0x3f441c) {
            }
        }
    }
    var _0x27a50e = null;
    class _0x5d7619 {
        constructor() {
            this[_0x152f('0x3b')] = ![], this[_0x152f('0xa6')] = ![], this[_0x152f('0xab')] = ![], this[_0x152f('0x43')] = ![], this[_0x152f('0x2a')] = -0x1, this[_0x152f('0xc4')] = ![], this[_0x152f('0x9a')] = ![];
        }
        ['init']() {
            return new Promise((_0x4a3ac7, _0x36b75f) => {
                try {
                    this[_0x152f('0x65')] = new _0x2e19ff(), this[_0x152f('0x95')] = new _0x2e19ff(), window[_0x152f('0x8c')][_0x152f('0xe')](_0x152f('0xa9'), this[_0x152f('0xae')][_0x152f('0x82')](this), !![]), window['document']['addEventListener'](_0x152f('0x55'), this[_0x152f('0xae')][_0x152f('0x82')](this), !![]), window[_0x152f('0x8c')][_0x152f('0xe')]('visibilitychange', this[_0x152f('0xcb')][_0x152f('0x82')](this)), this['tryToResumeIntervalId'] = setInterval(this[_0x152f('0xae')][_0x152f('0x82')](this), 0xc8), this[_0x152f('0x65')][_0x152f('0x22')]()[_0x152f('0x75')] = this[_0x152f('0x40')][_0x152f('0x82')](this), this[_0x152f('0x95')]['getContext']()['onstatechange'] = this[_0x152f('0x5f')][_0x152f('0x82')](this), this['beEnabled'] = !![], this[_0x152f('0x74')] = 0x3c, _0x4a3ac7(!![]);
                } catch (_0x5c8c26) {
                    console[_0x152f('0x7c')](_0x152f('0x9e'), _0x5c8c26), alert(_0x152f('0x68')), _0x4a3ac7(![]);
                }
            });
        }
        ['onVisibilitychange']() {
            if (window[_0x152f('0x60')]['adShowing'])
                return;
            if (document['visibilityState'] == _0x152f('0x7a'))
                !this[_0x152f('0xa6')] && (this[_0x152f('0xc4')] = this[_0x152f('0x3f')] = !![]);
            else
                document[_0x152f('0x63')] == 'visible' && (this[_0x152f('0xc4')] && (this[_0x152f('0xc4')] = this['muted'] = ![]));
        }
        ['onDBInstanceMuted']() {
        }
        [_0x152f('0xae')]() {
            if (this['isMuted'])
                return;
            if (this[_0x152f('0xab')] || this['bePauseMusic']) {
                window[_0x152f('0x8c')][_0x152f('0xce')](_0x152f('0xa9'), this[_0x152f('0xae')]['bind'](this), !![]), window[_0x152f('0x8c')][_0x152f('0xce')](_0x152f('0x55'), this[_0x152f('0xae')]['bind'](this), !![]), clearInterval(this[_0x152f('0x2a')]), this['tryToResumeIntervalId'] = -0x1;
                return;
            }
            this[_0x152f('0x65')]['isSuspend']() && this[_0x152f('0x65')][_0x152f('0x9')](), this[_0x152f('0x95')][_0x152f('0x61')]() && this[_0x152f('0x95')][_0x152f('0x9')](), (!this[_0x152f('0x65')][_0x152f('0x61')]() || !this[_0x152f('0x95')][_0x152f('0x61')]()) && (window[_0x152f('0x8c')]['removeEventListener'](_0x152f('0xa9'), this[_0x152f('0xae')]['bind'](this), !![]), window[_0x152f('0x8c')][_0x152f('0xce')]('touchstart', this[_0x152f('0xae')]['bind'](this), !![]), clearInterval(this[_0x152f('0x2a')]), this[_0x152f('0x2a')] = -0x1);
        }
        [_0x152f('0x40')]() {
            this[_0x152f('0x65')][_0x152f('0x61')]() && !this[_0x152f('0xa6')] && !this[_0x152f('0x43')] && this['tryToResumeIntervalId'] === -0x1 && (window[_0x152f('0x8c')][_0x152f('0xe')](_0x152f('0xa9'), this[_0x152f('0xae')][_0x152f('0x82')](this), !![]), window[_0x152f('0x8c')][_0x152f('0xe')](_0x152f('0x55'), this[_0x152f('0xae')][_0x152f('0x82')](this), !![]), this[_0x152f('0x2a')] = setInterval(this[_0x152f('0xae')]['bind'](this), 0xc8));
        }
        [_0x152f('0x5f')]() {
            this['soundAudio'][_0x152f('0x61')]() && !this['isMuted'] && !this[_0x152f('0xab')] && this[_0x152f('0x2a')] === -0x1 && (window[_0x152f('0x8c')][_0x152f('0xe')]('mousedown', this[_0x152f('0xae')][_0x152f('0x82')](this), !![]), window[_0x152f('0x8c')]['addEventListener'](_0x152f('0x55'), this['tryToResumeAudioContext']['bind'](this), !![]), this[_0x152f('0x2a')] = setInterval(this['tryToResumeAudioContext'][_0x152f('0x82')](this), 0xc8));
        }
        set [_0x152f('0x3f')](_0x41f658) {
            this[_0x152f('0xa6')] = _0x41f658, this['isMuted'] ? (this[_0x152f('0x65')][_0x152f('0xbc')](), this[_0x152f('0x95')]['suspend']()) : this[_0x152f('0x2a')] == -0x1 && (this[_0x152f('0x2a')] = setInterval(this[_0x152f('0xae')][_0x152f('0x82')](this), 0xc8));
        }
        get ['muted']() {
            return this['isMuted'];
        }
        set [_0x152f('0x2')](_0x5abbd9) {
            this['pauseSound'] = _0x5abbd9, this[_0x152f('0x10')] = _0x5abbd9;
        }
        get ['pause']() {
            return this[_0x152f('0xcd')] || this[_0x152f('0x10')];
        }
        set ['pauseSound'](_0x235a11) {
            this[_0x152f('0xab')] = _0x235a11;
            if (this['bePauseSound'])
                this[_0x152f('0x95')][_0x152f('0xbc')]();
            else {
                if (this[_0x152f('0xa6')])
                    return;
                this[_0x152f('0x95')][_0x152f('0x9')]();
            }
        }
        get [_0x152f('0xcd')]() {
            return this[_0x152f('0xab')];
        }
        get [_0x152f('0x10')]() {
            return this['bePauseMusic'];
        }
        set [_0x152f('0x10')](_0x14616c) {
            this[_0x152f('0x43')] = _0x14616c;
            if (this['bePauseMusic'])
                this[_0x152f('0x65')][_0x152f('0xbc')]();
            else {
                if (this[_0x152f('0xa6')])
                    return;
                this[_0x152f('0x65')][_0x152f('0x9')]();
            }
        }
        [_0x152f('0x66')]() {
            this['musicAudio']['stopAll'](), this[_0x152f('0x95')][_0x152f('0x66')]();
        }
        [_0x152f('0x6d')](_0x475919, _0x1fa5b2, _0x4b521d) {
            this[_0x152f('0x95')][_0x152f('0x6d')](_0x475919, _0x1fa5b2);
        }
        ['playMusic'](_0x10419a) {
            this['musicAudio'][_0x152f('0x66')](), this['musicAudio'][_0x152f('0x6c')](_0x10419a);
        }
        [_0x152f('0xaf')]() {
            this[_0x152f('0x65')][_0x152f('0x66')]();
        }
        [_0x152f('0x42')](_0x593b8b) {
            this[_0x152f('0x95')]['stop'](_0x593b8b);
        }
        set ['musicVolume'](_0xc9fb2a) {
            this[_0x152f('0x65')][_0x152f('0x74')] = _0xc9fb2a;
        }
        get [_0x152f('0x74')]() {
            return this[_0x152f('0x65')][_0x152f('0x74')];
        }
        ['playSound'](_0x513b4b, _0x5954b = ![], _0x1a0d82 = ![]) {
            if (!this['beEnabled'])
                return;
            this[_0x152f('0x95')]['play'](_0x513b4b, _0x5954b, _0x1a0d82);
        }
    }
    class _0x3e8098 {
    }
    class _0x2e19ff {
        constructor() {
            this[_0x152f('0x12')] = 0x64, this[_0x152f('0x48')] = new Map(), this[_0x152f('0x62')] = 0x64, window[_0x152f('0xac')] = window[_0x152f('0xac')] || window[_0x152f('0x5')], this[_0x152f('0x39')] = new AudioContext();
        }
        ['getContext']() {
            return this['context'];
        }
        [_0x152f('0x61')]() {
            return this['context'][_0x152f('0x6b')] === _0x152f('0x52');
        }
        [_0x152f('0xbc')]() {
            this['context'][_0x152f('0xbc')]();
        }
        [_0x152f('0x9')]() {
            this[_0x152f('0x39')]['resume']();
        }
        [_0x152f('0x66')]() {
            const _0x59575d = this[_0x152f('0x48')][_0x152f('0x23')]();
            for (const _0xeeb6d0 of _0x59575d) {
                const _0xd100f6 = _0xeeb6d0['instance'];
                if (_0xd100f6[_0x152f('0xa2')]['buffer']) {
                    try {
                        _0xd100f6[_0x152f('0xa2')][_0x152f('0xb4')](this[_0x152f('0x39')][_0x152f('0x3')]);
                    } catch (_0x3201d4) {
                        _0xd100f6[_0x152f('0xa2')]['disconnect']();
                    }
                    _0xd100f6[_0x152f('0xa2')][_0x152f('0x4e')] = function () {
                    }, _0xd100f6['setup']();
                }
            }
        }
        ['stop'](_0x24adfa) {
            if (this['_audioInstances'][_0x152f('0x70')](_0x24adfa)) {
                const _0xc0a79d = this[_0x152f('0x48')][_0x152f('0x35')](_0x24adfa);
                this['_stopSound'](_0xc0a79d);
            }
        }
        [_0x152f('0xb6')](_0xadbd6b) {
            const _0x2f8fe8 = _0xadbd6b[_0x152f('0x89')];
            if (_0x2f8fe8[_0x152f('0xa2')][_0x152f('0x1a')]) {
                try {
                    _0x2f8fe8['source'][_0x152f('0xb4')](this[_0x152f('0x39')]['currentTime']);
                } catch (_0x515e6b) {
                    _0x2f8fe8[_0x152f('0xa2')]['disconnect']();
                }
                _0x2f8fe8['source'][_0x152f('0x4e')] = function () {
                }, _0x2f8fe8[_0x152f('0xc1')]();
            }
        }
        [_0x152f('0x6c')](_0x5764a6) {
            this[_0x152f('0xcf')] && this['_stopSound'](this[_0x152f('0xcf')]), this[_0x152f('0x48')][_0x152f('0x70')](_0x5764a6) ? (this[_0x152f('0xcf')] = this[_0x152f('0x48')][_0x152f('0x35')](_0x5764a6), this[_0x152f('0x74')] = this[_0x152f('0x62')], this['play'](_0x5764a6, !![])) : this[_0x152f('0xb1')](_0x5764a6, () => {
                this[_0x152f('0x6c')](_0x5764a6);
            });
        }
        [_0x152f('0xaf')]() {
            this['_music'] && this['_stopSound'](this['_music']);
        }
        set [_0x152f('0x74')](_0x235cb8) {
            this[_0x152f('0x62')] = _0x235cb8, this[_0x152f('0xcf')] && (this[_0x152f('0xcf')][_0x152f('0x89')][_0x152f('0x26')][_0x152f('0x26')]['value'] = this[_0x152f('0x62')] / 0x64);
        }
        get ['musicVolume']() {
            return this[_0x152f('0x62')];
        }
        [_0x152f('0x27')](_0x35836c, _0x2bb19e = ![], _0x2cf523 = ![]) {
            if (this[_0x152f('0x48')]['has'](_0x35836c)) {
                const _0x25f02b = this[_0x152f('0x48')][_0x152f('0x35')](_0x35836c), _0x4812bf = _0x25f02b[_0x152f('0x89')];
                if (_0x2cf523 && !_0x4812bf[_0x152f('0x81')])
                    return;
                this[_0x152f('0xb4')](_0x35836c);
                if (_0x25f02b[_0x152f('0x1a')])
                    try {
                        _0x4812bf[_0x152f('0xc2')](this['context']['currentTime'], _0x25f02b['buffer']), _0x4812bf['source']['loop'] = _0x2bb19e;
                    } catch (_0x431daf) {
                        console[_0x152f('0x58')](_0x152f('0x2c') + _0x431daf);
                    }
            } else
                this[_0x152f('0xb1')](_0x35836c, () => {
                    this['play'](_0x35836c, _0x2bb19e);
                });
        }
        [_0x152f('0x1')](_0x47e7ad, _0x27cdea) {
            let _0x4858cf = _0x47e7ad[_0x152f('0x11')], _0xb0858f = 0x0;
            for (let _0x4377d3 = 0x0; _0x4377d3 < _0x47e7ad[_0x152f('0x11')]; _0x4377d3++) {
                const _0x552bee = _0x47e7ad[_0x4377d3];
                this['downloadArrayBuffer'](_0x552bee, () => {
                    _0xb0858f++, _0xb0858f >= _0x4858cf && (_0x27cdea && _0x27cdea());
                });
            }
        }
        ['setThreeD'](_0x13573b) {
            if (this[_0x152f('0x48')]['has'](_0x13573b)) {
                const _0x3c18bc = this[_0x152f('0x48')]['get'](_0x13573b);
                _0x3c18bc[_0x152f('0x89')][_0x152f('0x54')] = !![];
            }
        }
        [_0x152f('0x46')]() {
            let _0x573c94 = this[_0x152f('0x39')];
            const _0x2ee32a = {
                'gain': _0x573c94[_0x152f('0xbe')](),
                'panner': _0x573c94['createPanner'](),
                'threeD': ![],
                'ended': ![],
                'playBuffer': function (_0x3594b4, _0x4c7d0, _0x15ac18) {
                    this[_0x152f('0xa2')]['buffer'] = _0x4c7d0;
                    var _0x2837f7 = this;
                    this[_0x152f('0x81')] = ![], this[_0x152f('0xa2')][_0x152f('0x4e')] = function () {
                        _0x2837f7[_0x152f('0xc1')](), _0x2837f7[_0x152f('0x81')] = !![];
                    }, this['source']['start'](_0x3594b4, _0x15ac18);
                },
                'setup': function () {
                    this[_0x152f('0xa2')] = _0x573c94['createBufferSource'](), this[_0x152f('0x17')]();
                },
                'setupPanning': function () {
                    this[_0x152f('0x54')] ? (this[_0x152f('0xa2')][_0x152f('0x20')](), this['source'][_0x152f('0x3e')](this[_0x152f('0x67')]), this[_0x152f('0x67')][_0x152f('0x3e')](this['gain'])) : (this[_0x152f('0x67')][_0x152f('0x20')](), this[_0x152f('0xa2')]['connect'](this[_0x152f('0x26')]));
                }
            };
            return _0x2ee32a[_0x152f('0x67')][_0x152f('0xa7')] = 0x0, _0x2ee32a['gain'][_0x152f('0x3e')](this['context'][_0x152f('0x47')]), _0x2ee32a['setup'](), _0x2ee32a;
        }
        [_0x152f('0x6d')](_0x49a9f3, _0x1afa0e, _0x3dc8a0) {
            const _0x3e0268 = new _0x3e8098();
            _0x3e0268['url'] = _0x49a9f3, _0x3e0268[_0x152f('0x89')] = this[_0x152f('0x46')](), this[_0x152f('0x48')][_0x152f('0x72')](_0x49a9f3, _0x3e0268), this[_0x152f('0x39')][_0x152f('0x6f')](_0x1afa0e, function (_0x26a7b0) {
                _0x3e0268[_0x152f('0x1a')] = _0x26a7b0, _0x3dc8a0 && _0x3dc8a0();
            }, function (_0x4ffa19) {
                _0x3e0268[_0x152f('0x58')] = !![], _0x3dc8a0 && _0x3dc8a0(), console[_0x152f('0x7c')](_0x152f('0xc6') + _0x3e0268[_0x152f('0x2b')]);
            });
        }
        [_0x152f('0xb1')](_0x15f1fb, _0x2c9244) {
            if (this['_audioInstances']['has'](_0x15f1fb)) {
                _0x2c9244 && _0x2c9244();
                return;
            }
            const _0x9f516c = this;
            var _0x33d375 = new XMLHttpRequest();
            _0x33d375[_0x152f('0xa8')](_0x152f('0x2e'), _0x15f1fb, !![]), _0x33d375['responseType'] = _0x152f('0x8e'), _0x33d375['onload'] = function () {
                if (_0x33d375[_0x152f('0x56')] === 0xc8 || _0x33d375[_0x152f('0x56')] === 0x0)
                    _0x9f516c[_0x152f('0x6d')](_0x15f1fb, _0x33d375[_0x152f('0x44')], _0x2c9244);
                else
                    throw 'no\x20response';
            }, _0x33d375['onerror'] = function () {
                _0x2c9244 && _0x2c9244();
                throw _0x152f('0x3a');
            }, _0x33d375[_0x152f('0xb5')] = function () {
                _0x2c9244 && _0x2c9244();
            }, _0x33d375['onabort'] = function () {
                _0x2c9244 && _0x2c9244();
            }, _0x33d375[_0x152f('0x0')](null);
        }
    }
    const _0x797a3c = window['WebAudioEngine'] = new _0x5d7619();
    class _0x5e947f {
        constructor() {
            this['canNavigateActive_'] = ![], this[_0x152f('0x8')] = '', this[_0x152f('0xcc')] = '', this[_0x152f('0x41')] = '', this[_0x152f('0x14')] = null, this[_0x152f('0x85')] = ![], this[_0x152f('0x4d')] = ![], this[_0x152f('0xc5')] = ![], this[_0x152f('0xa3')]();
        }
        static [_0x152f('0x59')]() {
            return !this[_0x152f('0x9f')] && (this[_0x152f('0x9f')] = new _0x5e947f()), this['_instance'];
        }
        [_0x152f('0xa3')]() {
            let _0x1c8489 = document[_0x152f('0x28')](_0x152f('0x90'));
            _0x1c8489 && (_0x1c8489[_0x152f('0xe')](_0x152f('0x30'), this[_0x152f('0xb')][_0x152f('0x82')](this)), _0x1c8489[_0x152f('0xe')]('touchend', this[_0x152f('0xb')][_0x152f('0x82')](this)));
        }
        [_0x152f('0xb')]() {
            if (YYGSDK[_0x152f('0x9d')])
                return;
            this[_0x152f('0xbf')] && (_0x27a50e ? _0x27a50e['navigate'](this[_0x152f('0x8')], this[_0x152f('0xcc')], this[_0x152f('0x41')]) : YYGSDK[_0x152f('0x5b')](this['screen_'], this[_0x152f('0xcc')], this[_0x152f('0x41')])), this[_0x152f('0xbf')] = ![];
        }
        [_0x152f('0x19')](_0x2f0c5a) {
            let _0x25fc59 = null;
            try {
                let _0x3cff8c = Laya[_0x152f('0x5c')][_0x152f('0x4')](_0x2f0c5a);
                _0x25fc59 = JSON['parse'](_0x3cff8c);
            } catch (_0x4df9ed) {
            }
            return _0x25fc59;
        }
        ['setStorageSync'](_0x219b09, _0x2a59d9) {
            return Laya[_0x152f('0x5c')]['setItem'](_0x219b09, JSON[_0x152f('0x99')](_0x2a59d9));
        }
        ['navigate'](_0x5e61dd, _0x3d00ff, _0x363d91) {
            if (!_0x5e947f[_0x152f('0x59')]()[_0x152f('0xc5')])
                return;
            this[_0x152f('0xbf')] === ![] && (this['screen_'] = _0x5e61dd, this[_0x152f('0xcc')] = _0x3d00ff, this['to_'] = _0x363d91, this[_0x152f('0xbf')] = !![]);
        }
        [_0x152f('0x7d')]() {
            _0x797a3c[_0x152f('0x3f')] = !![];
            ;
        }
        [_0x152f('0xb0')]() {
            _0x797a3c[_0x152f('0x3f')] = ![];
        }
        ['showInterstitial'](_0x268eb7) {
            window[_0x152f('0x60')][_0x152f('0x9a')] = !![];
            if (!this['initialized_']) {
                window['WebAudioEngine'][_0x152f('0x9a')] = ![], _0x268eb7 && _0x268eb7();
                return;
            }
            this['onblur']();
            if (_0x27a50e) {
                _0x27a50e[_0x152f('0x69')](() => {
                    window[_0x152f('0x84')](), this[_0x152f('0xb0')](), _0x268eb7 && _0x268eb7();
                });
                return;
            }
            YYGSDK['showInterstitial'](() => {
                window[_0x152f('0x84')](), this['onfocus'](), window['WebAudioEngine']['adShowing'] = ![], _0x268eb7 && _0x268eb7();
            });
        }
        [_0x152f('0x4b')](_0x2581b7, _0x2db032) {
            window[_0x152f('0x60')][_0x152f('0x9a')] = !![];
            if (!this['initialized_']) {
                window[_0x152f('0x60')]['adShowing'] = ![], _0x2581b7 && _0x2581b7();
                return;
            }
            this[_0x152f('0x7d')]();
            if (_0x27a50e) {
                _0x27a50e['showReward'](() => {
                    window['focus'](), this['onfocus'](), _0x2581b7 && _0x2581b7(), _0x2581b7 = null;
                });
                return;
            }
            YYGSDK['adsManager'][_0x152f('0x49')](YYG[_0x152f('0xc8')][_0x152f('0x33')], YYG['EventHandler']['create'](this, () => {
                window[_0x152f('0x84')](), this[_0x152f('0xb0')](), window[_0x152f('0x60')][_0x152f('0x9a')] = ![], _0x2581b7 && _0x2581b7(), _0x2581b7 = null;
            }), YYG['EventHandler']['create'](this, _0xb327ba => {
                window[_0x152f('0x84')](), this[_0x152f('0xb0')](), window[_0x152f('0x60')][_0x152f('0x9a')] = ![], _0x2db032 ? (_0x2db032(), _0x2db032 = null) : _0xb327ba == YYG['Event'][_0x152f('0x3c')] && this[_0x152f('0x8a')](_0x152f('0x91'));
            }));
        }
        ['initList'](_0x437c9b) {
            if (YYGSDK['isGamedistribution']) {
                _0x437c9b['visible'] = ![];
                return;
            }
            _0x437c9b[_0x152f('0x8f')] = new Laya[(_0x152f('0x57'))](_0x437c9b, function (_0xcc1449) {
                _0xcc1449['offAll'](Laya['Event'][_0x152f('0x53')]), _0xcc1449['on'](Laya['Event']['MOUSE_DOWN'], _0xcc1449, () => {
                    _0x5e947f[_0x152f('0x59')]()[_0x152f('0x5b')](_0x152f('0xc7'), _0x152f('0x6e'), _0xcc1449[_0x152f('0x21')]['id']);
                });
            }), _0x437c9b[_0x152f('0x50')] = _0x5e947f[_0x152f('0x59')]()['getForgames']();
        }
        ['prompt'](_0x9e2e34, _0x22a279) {
            !this[_0x152f('0x14')] && (this[_0x152f('0x14')] = document[_0x152f('0x4a')]('div'), this[_0x152f('0x14')][_0x152f('0x3d')][_0x152f('0xb3')] = _0x152f('0xf'), document[_0x152f('0xb2')][_0x152f('0xc0')](this['prompt_'])), this[_0x152f('0x14')]['innerHTML'] = _0x9e2e34, _0x22a279 = isNaN(_0x22a279) ? 0x7d0 : _0x22a279, this[_0x152f('0x14')][_0x152f('0x3d')]['display'] = _0x152f('0x5a'), this['prompt_']['style'][_0x152f('0x79')] = '1', setTimeout(function () {
                var _0x318045 = 0.5;
                this[_0x152f('0x14')][_0x152f('0x3d')][_0x152f('0xbb')] = _0x152f('0x7') + _0x318045 + _0x152f('0xba') + _0x318045 + 's\x20ease-in', this['prompt_'][_0x152f('0x3d')]['opacity'] = '0', this[_0x152f('0x14')][_0x152f('0x3d')][_0x152f('0xa4')] = _0x152f('0x5e');
            }[_0x152f('0x82')](this), _0x22a279);
        }
        [_0x152f('0x2f')]() {
            let _0x10cf18 = YYGSDK[_0x152f('0x94')] || [], _0x1a4971 = _0x10cf18['slice']();
            for (let _0x4b4076 = 0x0, _0x29a4c8 = _0x1a4971[_0x152f('0x11')]; _0x4b4076 < _0x29a4c8; _0x4b4076++) {
                const _0x348f0c = Math[_0x152f('0x5d')](Math[_0x152f('0xad')]() * (_0x4b4076 + 0x1)), _0x9ca1a0 = _0x1a4971[_0x348f0c];
                _0x1a4971[_0x348f0c] = _0x1a4971[_0x4b4076], _0x1a4971[_0x4b4076] = _0x9ca1a0;
            }
            return _0x1a4971;
        }
        [_0x152f('0x7e')]() {
            const _0x526572 = new Laya[(_0x152f('0xca'))]();
            return _0x526572[_0x152f('0x8d')] = 'yad.png', _0x526572[_0x152f('0x4c')] = 0x7d0, Laya[_0x152f('0x4f')]['addChild'](_0x526572), _0x526572['on'](Laya[_0x152f('0x16')][_0x152f('0x53')], _0x526572, () => {
                _0x5e947f['getInstance']()[_0x152f('0x5b')](_0x152f('0xc7'), _0x152f('0x8b'));
            }), _0x526572;
        }
        ['yadstartup'](_0x299fe7, _0x3b0ae3) {
            if (this[_0x152f('0x85')])
                return;
            window[_0x152f('0x60')][_0x152f('0x2d')]()[_0x152f('0x86')](() => {
                Laya['SoundManager'][_0x152f('0x6c')] = function (_0x33cc67) {
                    window[_0x152f('0x60')] && window['WebAudioEngine'][_0x152f('0x6c')](_0x33cc67);
                }, Laya['SoundManager']['playSound'] = function (_0x3c5610) {
                    window[_0x152f('0x60')] && window['WebAudioEngine'][_0x152f('0x32')](_0x3c5610);
                };
            }), this[_0x152f('0x85')] = !![], Laya['loader']['load'](_0x152f('0x18'), Laya['Handler'][_0x152f('0x77')](this, _0x5edb86 => {
                this[_0x152f('0x4d')] = !![], this[_0x152f('0x85')] = ![];
                const _0x197258 = _0x5edb86[_0x152f('0x97')];
                if (_0x197258 && _0x197258[_0x152f('0xc9')]()[_0x152f('0x11')] > 0x5)
                    _0x27a50e = new _0x1c7578(), _0x27a50e['adsAsyncInit'](_0x299fe7, YYG[_0x152f('0x1b')][_0x152f('0x98')], _0x197258)[_0x152f('0x86')](() => {
                        this[_0x152f('0x85')] = !![], _0x3b0ae3 && _0x3b0ae3();
                    });
                else {
                    YYGSDK['on'](YYG[_0x152f('0x16')]['YYGSDK_INITIALIZED'], this, () => {
                        _0x3b0ae3 && _0x3b0ae3(), _0x3b0ae3 = null, this[_0x152f('0x85')] = !![];
                    });
                    let _0x58cf87 = new YYG[(_0x152f('0x37'))]();
                    _0x58cf87['gameNameId'] = _0x299fe7, _0x58cf87[_0x152f('0x1c')] = _0x5edb86['id'] || '', YYGSDK[_0x152f('0x1f')](YYG[_0x152f('0x1b')]['YAD'], _0x58cf87);
                }
                this[_0x152f('0xc5')] = !![];
            }));
        }
        [_0x152f('0x45')](_0x46b3d9, _0x3effeb) {
            if (this[_0x152f('0x85')])
                return;
            window[_0x152f('0x60')][_0x152f('0x2d')]()['then'](() => {
                Laya[_0x152f('0x7b')]['playMusic'] = function (_0x14ffbe) {
                    window['WebAudioEngine'][_0x152f('0x6c')](_0x14ffbe);
                }, Laya[_0x152f('0x7b')][_0x152f('0x32')] = function (_0x2bd5bb) {
                    window[_0x152f('0x60')]['playSound'](_0x2bd5bb);
                };
            }), this[_0x152f('0x85')] = !![], Laya[_0x152f('0x83')][_0x152f('0x77')](_0x152f('0x18'), Laya[_0x152f('0x57')][_0x152f('0x77')](this, _0xad5a2c => {
                this[_0x152f('0x85')] = ![];
                const _0x323665 = _0xad5a2c[_0x152f('0x97')];
                if (_0x323665 && _0x323665[_0x152f('0xc9')]()[_0x152f('0x11')] > 0x5)
                    _0x27a50e = new _0x1c7578(), _0x27a50e[_0x152f('0xaa')](_0x46b3d9, YYG[_0x152f('0x1b')]['YAD'], _0x323665)[_0x152f('0x86')](() => {
                        this[_0x152f('0x85')] = !![], _0x3effeb && _0x3effeb();
                    });
                else {
                    YYGSDK['on'](YYG[_0x152f('0x16')][_0x152f('0x9b')], this, () => {
                        _0x3effeb && _0x3effeb(), _0x3effeb = null, this[_0x152f('0x85')] = !![];
                    });
                    let _0x103c90 = new YYG[(_0x152f('0x37'))]();
                    _0x103c90[_0x152f('0xb7')] = _0x46b3d9, _0x103c90[_0x152f('0x1c')] = _0xad5a2c['id'] || '', YYGSDK[_0x152f('0x1f')](YYG[_0x152f('0x1b')][_0x152f('0xa0')], _0x103c90);
                }
            }));
        }
    }
    _0x5e947f['_instance'] = null, window['platform'] = _0x5e947f;
}();